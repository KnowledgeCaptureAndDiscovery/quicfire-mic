from typing import Tuple
import itertools
import os

import requests

from bp3d import utils
from bp3d.output import *
from bp3d.ensemble import Ensemble

class Client:

    def __init__(self, user=None, password=None, url='https://burnpro3d.sdsc.edu/api'):
       
        self._url_api = url


    def fuel(self, ftype: str = 'FastFuels', 
        lon: float = None, lat: float = None,
        radius: int = None, xlen: int = None, ylen: int = None,
        res_xyz: Tuple[int, int, int] = (2, 2, 1),
        **fuel_args):
        """Create fuel for an ensemble. If radius is specified, fuel domain
        is a square with side length twice the radius. If xlen and ylen
        are specified, fuel domain is a rectangle. Either radius or xlen 
        and ylen must be specified, but not both.

        Parameters
        ----------
        lon : float
            Longitude of center
        lat : float
            Latitude of center
        radius : int, optional
            Radius of fuel domain square
        xlen : int, optional
            Length in the x direction of fuel domain rectangle
        ylen : int, optional
            Length in the y direction of fuel domain rectangle
        res_xyz : (int, int, int), optional
            Resolution (in meters) in the x, y, z dimensions of the fuel.
        fuel_args : kwargs
            Keyword args specific to fuel type.
        """

        if ftype not in ['FastFuels', 'uniform']:
            raise ValueError('fuel type must be either FastFuels or uniform')


        # hard-code minimum size so that ignition coordinates are within fuel domain
        if radius is not None and radius < 250:
            raise ValueError('fuel domain length/width must be >= 500')

        for n in [xlen, ylen]:
            if n is not None and n < 500:
                raise ValueError('fuel domain length/width must be >= 500')
     
        if radius is not None and (xlen is not None or ylen is not None):
            raise ValueError('specify either radius or xlen/ylen, but not both.')

        if not any([radius, xlen, ylen]):
            raise ValueError('specify either radius or xlen/ylen.')

        
        if ftype == 'uniform':

            if radius is not None:
                xlen = radius * 2
                ylen = radius * 2

            return self.output(otype='fuel', xlen=xlen, ylen=ylen, **fuel_args)

        else:

            r = requests.get(self._url_api + '/v1/fueler', json={
                'lat': lat,
                'lon': lon,
                'radius': radius,
                'xlen': xlen,
                'ylen': ylen,
                'res_xyz': res_xyz
            })

            j = utils.check_response(r)
            
            if 'fuel_id' not in j:
                raise Exception('no fuel_id in response from server')

            return self.output(id=j['fuel_id'], otype='fuel')
 

    def ignition(self, dat=None, perc=None):
        """ Get an ignition

        Parameters
        ----------
        dat: list(str), optional
            Contents of ignite.dat, each line is an element.
        perc: int, optional
            Percent (between 0 and 1) of fire in ignition 
            (only when dat is specified).
        """

        ig = None

        dat_str = None
        if dat is not None:
            if not os.path.isfile(dat):
                raise ValueError('ignition file does not exist:', dat)

            if perc is None:
                raise ValueError('must specify perc with dat.')

            ig = {
                'perc': perc
            }

            with open(dat) as f:
                ig['dat'] = f.readlines()

        return ig

    def ensemble(self, sim_time: int, cartesian: bool = False, **kwargs):
        """Start an ensemble of model runs.

        Parameters
        ----------
        sim_time: int
            Simulation time (in seconds)
        cartesion: bool, optional
            If true, ensemble will consistent of the cartesian product of
            each value in kwargs. If false, each list value in kwargs must 
            be the same size, and the ith element in each corresponds to the
            parameters of the ith run.
        kwargs: **kwargs
            Names and values of model parameters
        """

        if sim_time < 1:
            raise ValueError('sim_time must be > 0.')

        ens_size = None

        for k, v in kwargs.items():

            found = False
            for t in [int, float, list, object]:
                if isinstance(v, t):
                    found = True
                    break

            if not found:
                raise ValueError('unknown type for', k, type(v))

            if isinstance(v, list):
                size = len(v)
               
                if not cartesian:
                    if ens_size is None:
                        ens_size = size
                    elif ens_size != size:
                        raise ValueError('all list params must be same size if cartesian = False.')
            elif cartesian:
                kwargs[k] = [v]

       
        # serialize FuelOutputs
        if isinstance(kwargs['fuel'], FuelOutput):
            kwargs['fuel'] = kwargs['fuel'].serialize()
        else:
            fuel_fixed = [] 
            for f in kwargs['fuel']:
                fuel_fixed.append(f.serialize())

            kwargs['fuel'] = fuel_fixed

        #print(kwargs)

        if cartesian:
            perms = self._product_dict(**kwargs)
        else:

            if ens_size is None:
                ens_size = 1
            #print('ens_size', ens_size)

            perms = [{} for _ in range(ens_size)]
            for k, v in kwargs.items():
                for i in range(ens_size):
                    if isinstance(v,list):
                        perms[i][k] = v[i]
                    else:
                        perms[i][k] = v

        dicts = [dict(sim_time=sim_time, **p) for p in perms]
        return Ensemble(self._url_api, dicts)


    def load_ensemble(self, name: str):
        """Load an ensemble from a file.

        Parameters
        ----------
        name: str
            File name containing ensemble
        """

        ens = Ensemble(self._url_api, None)
        ens.load(name)
        return ens


    def output(self, otype: str = None, **kwargs):
        """Create an output object.

        Parameters
        ----------
        otype: str
            Output type.
        kwargs: kwargs
            Keyword arguments specific to output.
        """

        if otype == 'fuel':
            return FuelOutput(self._url_api, **kwargs)
        elif otype == 'quicfire':
            return ModelOutput(self._url_api, **kwargs)
        
        raise ValueError('Unknown type', otype)


    def _product_dict(self, **kwargs):
        """Generate the cartesian product of kwargs"""

        k = kwargs.keys()
        v = kwargs.values()
        for i in itertools.product(*v):
            yield dict(zip(k, i))
