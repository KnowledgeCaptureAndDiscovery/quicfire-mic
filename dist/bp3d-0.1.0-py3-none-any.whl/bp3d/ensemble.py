
import json
import os
import time
import uuid

from tqdm import tqdm
import pandas as pd
import requests

from bp3d import utils
from bp3d.output import ModelOutput

class Ensemble:

    def __init__(self, url_api, dicts):
        self._url_api = url_api
        
        self._df = pd.DataFrame(dicts)
        self._init_df()

    
    def _init_df(self):
        """Initialize the state of a dataframe."""

        for n in ['run_id', 'st_state', 'st_status']:
            if n not in self._df.columns:
                self._df[n] = 'unknown'

        self._df['st_done'] = 0

        # check if row indexes are run_ids. if so, store in run_id
        # column and reset index back to ints.
        idx_is_run_id = False
        for idx in self._df.index:
            try:
                if type(idx) == str and uuid.UUID('{' + idx + '}'):
                    idx_is_run_id = True
                    self._df.at[idx, 'run_id'] = idx
            except:
                pass
    
        if idx_is_run_id:
            self._df.reset_index(inplace=True, drop=True)


    def _state(self, k, v):
        return self._df[self._df[k] == v]


    def complete(self, timeout=600, verbose=False, fast_fail=False, show_pbar=False):
        """Wait until the ensemble completes or the timeout (in seconds) expires.

        Parameters
        ----------
        timeout: int
            Time (s) to wait for completion.
        verbose: bool
            If true, print verbose status output
        fast_fail: bool
            If true, return if any run fails instead of waiting for all runs
            to complete.
        show_pbar: bool
            If true, show a progress bar.
        """

        if show_pbar:
            pbar = tqdm(total=100)
        else:
            pbar = None


        try:
            start = time.time()
            while time.time() - start < timeout:
                perc = self.status(fast_fail=fast_fail)

                # see if we fast-failed
                if perc is None:
                    return

                if show_pbar:
                    pbar.update(perc - pbar.n)
    
                if verbose:
                    print('elapsed', int(time.time() - start), 's')
                    print(self._df.to_string(index=False))
    
                complete = True
                failed = True
    
                for _, row in self._df.iterrows():
    
                    if row['st_state'] != 'SUCCESS':
                        complete = False

                        if row['st_state'] != 'FAILURE':
                            failed = False
   
                if complete:
                    return

                if failed:
                    print('all runs failed.')
                    return
    
                time.sleep(60)

            raise TimeoutError('timeout waiting completion')

        finally:
            if pbar is not None:
                pbar.close()

    
    @property
    def df(self):
        """Get the ensemble dataframe"""
        return self._df


    @property
    def errors(self):
        """Get runs that have failed."""
        return self._state('st_state', 'FAILURE')

    
    def execute(self, df=None, retry: str=None) -> None:
        """Execute ensemble.

        Parameters
        ----------
        df: dataframe
            Subset of runs to execute. If not specified, execute all runs.
        retry: str
            Retry 'all' or 'failed' runs.
        """

        if retry not in [None, 'all', 'failed']:
            raise ValueError('retry must be None, "all", or "failed"')

        if df is None:
            df = self._df

        self.status(df=df)

        for idx, row in df.iterrows():

            #print(row['run_id'], row['st_state'])

            if row['run_id'] != 'unknown':
               
                if row['st_state'] == 'FAILURE':
                    if retry is None:
                        print('skipping failed', row['run_id'])
                        continue
                elif row['st_state'] == 'SUCCESS':
                    if retry != 'all':
                        print('skipping success', row['run_id'])
                        continue
                else:
                    print('skipping running', row['run_id'])
                    continue

            d = dict(row)

            # remove status from the dataframe since starting the run
            for n in ['st_state', 'st_status']:
                self._df.at[idx, n] = 'unknown'

                # remove status from parameters passed to endpoint
                del d[n]

            self._df.at[idx, 'st_done'] = 0
            del d['st_done']

            print('starting', d)

            # submit the jobs
            r = requests.post(self._url_api + '/v1/quicfire', json=d)
            j = utils.check_response(r)
            self._df.at[idx, 'run_id'] = j['task_id']


    def load(self, name: str) -> None:
        """Load an ensemble saved from a file.

        Parameters
        ----------
        name: str
            File name containing ensemble
        """

        if not os.path.isfile(name):
            raise ValueError('file does not exist', name)

        j = None
        with open(name) as f:
            j = json.load(f) 

        if 'type' not in j:
            raise ValueError('unknown type.')
        if j['type'] != 'ensemble':
            raise ValueError('unknown type', j['type'])

        self._df = pd.read_json(j['df'])
        self._init_df()

        # for backwards-compatibility, check for fuel_id
        if 'fuel_id' in self._df.columns:
            print('converting fuel_id to fuel')
            self._df['fuel'] = None
            for idx, row in self._df.iterrows():
                self._df.at[idx, 'fuel'] = { 'id': row['fuel_id'] }
            self._df.drop('fuel_id', axis=1, inplace=True)


    def status(self, fast_fail=False, df=None) -> int:
        """Update the status for each run. Returns the percentage
        (between 0 and 100) of ensemble completion.

        Parameters
        ----------
        fast_fail: bool
            If true, stops querying status when finding first failure
            and returns None.
        df: dataframe
            Subset of runs on which to update status. If not specified,
            update all runs.
        """ 
          
        if df is None:
            df = self._df

        count = 0
        for idx, row in df.iterrows():

            if row['run_id'] == 'unknown':
                continue
            
            # only check status for runs still going
            if row['st_state'] == 'SUCCESS':
                count += 100
                continue

            if row['st_state'] == 'FAILURE':
                continue

            r = requests.get(self._url_api + '/v1/tasks/' + row['run_id'])
            status = utils.check_response(r)

            # update the state fields
            self._df.at[idx, 'st_state'] = status['state']
            self._df.at[idx, 'st_status'] = status['status']
            self._df.at[idx, 'st_done'] = status['current']

            if fast_fail and status['state'] == 'FAILURE':
                print('FAILURE', row['run_id'], status['status'])
                return None

            count += status['current']

        return int(count / len(df))


    def output(self, df=None):
        """Get the output for one or more runs.

        Parameters
        ----------
        df: dataframe
            A dataframe of one or more runs.
        """

        if df is None:
            df = self._df

        if len(df) == 0:
            raise ValueError('No run specified.')

        return [ModelOutput(self._url_api, id=x) for x in df['run_id']]


    def save(self, name: str, overwrite: bool=False) -> None:
        """Save the ensemble to a file.

        Parameters
        ----------
        name: str
            File name.
        overwrite: bool
            If true, overwrite any existing file.
        """

        if os.path.isfile(name) and not overwrite:
            raise ValueError('file already exists', name)


        j = {'type': 'ensemble', 'df': self._df.to_json()}

        with open(name, 'w') as f:
            json.dump(j, f)
