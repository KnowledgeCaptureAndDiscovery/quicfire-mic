from urllib.parse import urlparse

import requests
import s3fs
import zarr

from bp3d import utils

class Output:

    def __init__(self, url_api, **kwargs):

        self._url_api = url_api
        self._kwargs = kwargs

        self._id = None

        if 'id' in kwargs:
            self._id = kwargs['id']

            r = requests.get(url_api + '/v1/paths/' + self._id)
            j = utils.check_response(r)

            self._archive_url = j['url']

            url = urlparse(j['url'])
            self._archive_endpoint = url.scheme + "://" + url.hostname
            if url.port:
                self._archive_endpoint += ":" + str(url.port)
            self._archive_path = url.path


    @property
    def fs(self):
        """ Get file system object storing this output."""
        return s3fs.S3FileSystem(anon=True,
            client_kwargs={
                'endpoint_url': self._archive_endpoint,
                'verify': False
            }
        )


    @property
    def id(self):
        """Get output id."""
        return self._id


    @property
    def otype(self):
        """Get output type."""
        raise Exception('Must be overridden by subclass.')

    
    @property
    def path(self):
        """Get path on archive"""
        return self._archive_path
   
    def viz(self, vtype, var, depth=None, timestep=None, use_cache=True, scale='linear'):
        """Generate a vizualization output on the server.

        Parameters
        ----------
        vtype : str
            Type of vizualization
        var : str
            Variable to vizualize
        depth : int, optional
            Depth to create 2D slice.
        timestep : int, optional
            Output timestep. 
        use_cache : bool, optional
            If true, only generate vizualization if does not already exist.
        scale: str, optional
            color scale, either linear or log
        """

        if self.id is None:
            raise ValueError('output cannot be visualized.')

        j = {
            'id': self.id,
            'var_type': var,
            'use_cache': use_cache,
            'out_type': vtype,
            'depth': depth,
            'timestep': timestep,
            'scale': scale
        }

        #print(self._url_api + '/v1/viz/' + self.otype)
        #print(j)
        r = requests.get(self._url_api + '/v1/viz/' + self.otype, json=j)
        j = utils.check_response(r)

        #print(j['outputs'])
        for i in range(len(j['outputs'])):
            if j['outputs'][i].index(self._archive_endpoint) == 0:
                j['outputs'][i] = j['outputs'][i][len(self._archive_endpoint):]

        return j['outputs']


    @property
    def zarr(self):
        """Get the zarr object."""

        if self._archive_path is None:
            raise ValueError('output has no zarr file.')

        root = self._archive_path + '/' + self._zarr_name
        store = s3fs.S3Map(root=root, s3=self.fs, check=False)
        return zarr.open(store)


    @property
    def _zarr_name(self):
        raise Exception('Must be overridden by subclass.')


class FuelOutput(Output):

    @property
    def otype(self):
        """Get output type."""
        return 'fuel'

    def serialize(self):
        return self._kwargs

    @property
    def _zarr_name(self):
        return 'fastfuels.zarr'


class ModelOutput(Output):

    @property
    def otype(self):
        """Get output type."""
        return 'run'

    @property
    def _zarr_name(self):
        return 'quicfire.zarr'
