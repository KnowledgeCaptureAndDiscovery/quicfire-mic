
def check_response(resp):
    """Check REST response for error."""

    if resp.status_code != 200:
        try:
            j = resp.json()
        except:
            raise Exception(resp.text)
            
        if 'detail' in j:
            raise Exception(j['detail'])

    return resp.json()
